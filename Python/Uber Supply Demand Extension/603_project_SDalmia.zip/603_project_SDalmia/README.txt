1. Start Anaconda Navigator from anaconda prompt using 'anaconda-navigator' command.
2. Launch JupyterLab by clicking on 'Launch' button for JupyterLab. JupyterLab should be opened in the browser window.
3. Copy the path of folder '603_project_SDalmia' from the local user directory like 'C:\Users....\603_project_SDalmia'
4. Select 'Open from Path' option from File menu of JupyterLab.
5. Paste the path copied in step3 and clik 'open' button. Folder should open on the left.
6. Open the 'UberDemandSupplyProblem.ipynb' file by double clicking.
7. From 'Run' menu select 'Run All Cells' option to execute the jupyter notebook.